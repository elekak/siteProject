var objM = {
    init: function(){
        carousels: {

            //carousel
        }

        def:  {

            function preloader(){
                $('.preload').delay(500).fadeOut('slow');
            }
            $('.preload').length ? preloader() : '';


            $('#mobilephone, #phone').mask('+7 999 999-99-99');


            $('.call').click(function (e) {
                e.preventDefault();
                $('#exampleModal').modal();
            });


            //
            // $(function () {
            //     $('[data-toggle="tooltip"]').tooltip()
            // })
            /*
            var colorStyle = {
                init: function (selector, enable) {
                    var style = {
                        init: function (id) {

                            if(enable) {
                                switch (id){
                                    case 0:
                                        //blue
                                        document.getElementById('main-style').href="/assets/components/project/app/css/main.colors/main.blue.min.css";
                                        break;
                                    case 1:
                                        //swamp
                                        document.getElementById('main-style').href="/assets/components/project/app/css/main.colors/main.swamp.min.css";
                                        break;
                                    case 2:
                                        //sand
                                        document.getElementById('main-style').href="/assets/components/project/app/css/main.colors/main.sand.min.css";
                                        break;
                                    case 3:
                                        //red
                                        document.getElementById('main-style').href="/assets/components/project/app/css/main.colors/main.red.min.css";
                                        break;
                                    case 4:
                                        //blue-green
                                        document.getElementById('main-style').href="/assets/components/project/app/css/main.colors/main.blue-green.min.css";
                                        break;
                                    default:
                                        //main
                                        document.getElementById('main-style').href="/assets/components/project/app/css/main.min.css";

                                }
                            } else {
                                localStorage.removeItem('cId');
                                document.getElementById('main-style').href="/assets/components/project/app/css/main.min.css";
                            }
                        }
                    };
                    $(selector).find('li').each(function () {
                        var ths         = $(this);

                        ths.removeClass('active');
                        var _cId = localStorage.getItem('cId');
                        if ( _cId === null ) { return false } else {
                            $(selector).find('li').eq(_cId).addClass('active');
                        }
                        var _cId  = Number(_cId);
                        style.init(_cId);
                    })
                    $(selector).find('span').click(function() {
                        $(selector).find('li').removeClass('active');
                        $(this).parent().addClass('active');

                        var cId = $(this).data('color-id');
                        localStorage.setItem('cId', cId);
                        style.init(cId);
                    });
                }
            }; colorStyle.init('.color-style', true);
            */


            window.addEventListener('resize', function () {

            });


            //add js

        }
    }
};

$(document).ready(function () {
    objM.init();
});